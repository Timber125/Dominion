html-client kan geen interacties afhandelen.
Hoofdgebruik momenteel is "spectate". 
Connect en login via html-client, maar doe geen join of connect. 