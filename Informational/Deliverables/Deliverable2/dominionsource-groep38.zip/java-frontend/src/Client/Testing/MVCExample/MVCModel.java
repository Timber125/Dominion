/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Client.Testing.MVCExample;

/**
 *
 * @author admin
 */
public class MVCModel {

    public MVCController myControl;
    
    void intialize(MVCController myControl) {
        this.myControl = myControl;
    }
    
}
